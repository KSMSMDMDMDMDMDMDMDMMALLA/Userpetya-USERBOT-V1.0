import time
import asyncio
from telethon import TelegramClient, events

# Укажи свои API_ID и API_HASH

API_ID = 23694672  # Замени на свой API_ID

API_HASH = "08cec06fe04dc359e88530e0b7f025a7"  # Замени на свой API_HASH

# Вход в клиент (используется сессионый файл)
client = TelegramClient("userbot_session", API_ID, API_HASH)


@client.on(events.NewMessage(outgoing=True, pattern=r"^\.help$"))
async def help_command(event):
    help_text = (
        "🌟 **UserPetya — список команд** 🌟\n\n"
        "🏓 **.ping** — Проверяет пинг и отправляет задержку в ms.\n"
        "😡 **.angry** — Заменяет сообщение на ругательства в течение 5 секунд.\n"
        "📌 **.zakrep** — Спамит закреплением и откреплением сообщения каждую секунду.\n"
        "🕵️ **.userinfo** — Показывает информацию о пользователе.\n"
        "✏️ **.prefix [текст]** — Добавляет префикс к сообщениям.\n"
        "🚫 **.prefoff** — Отключает префикс.\n\n"
        
        "💌 **.love [текст]** — Анимированное сердце с вашим текстом (по умолчанию 'LOVE YOU!').\n"
        "⚡ **.spam [текст] [время (сек)] [интервал (сек)]** — Спамит указанное сообщение с заданным интервалом.\n"
        "🔲 **.filter [триггер] [ответ]** — Добавляет автоответ на определённое сообщение.\n"
        "❌ **.unfilter [триггер]** — Удаляет фильтр для указанного триггера.\n"
        "📜 **.filters** — Показывает список всех активных фильтров.\n\n"
        
        "ℹ️ **.help** — Показывает этот список команд.\n\n"
        "⚡ *Бот управляет вашим аккаунтом, будьте осторожны!*"
    )
    await event.edit(help_text)  # Редактируем сообщение, заменяя на справку



@client.on(events.NewMessage(outgoing=True, pattern=r"^\.love(?: (.+))?$"))
async def love_command(event):
    custom_text = event.pattern_match.group(1) or "LOVE YOU!"  # Получаем текст или ставим стандартный
    
    hearts = [
        "💛",
        "💛💚",
        "💛💚💙",
        "💛💚💙💜",
        "💛💚💙💜❤️",
        "💛💚💙💜❤️💖",
        "💛💚💙💜❤️💖💗",
        "💛💚💙💜❤️💖💗💓",
        "💛💚💙💜❤️💖💗💓💞",
        "💛💚💙💜❤️💖💗💓💞💕",
        f"💖💖💖 **{custom_text}** 💖💖💖"
    ]
    
    for heart in hearts:
        await event.edit(heart)
        await asyncio.sleep(0.5)  # Задержка анимации


filters = {}  # Словарь для хранения фильтров

# Команда для добавления фильтра
@client.on(events.NewMessage(outgoing=True, pattern=r"^\.filter (.+) (.+)$"))
async def add_filter(event):
    global filters
    args = event.pattern_match.groups()
    trigger = args[0].lower()  # Триггер (на что реагировать)
    response = args[1]  # Ответ бота

    filters[trigger] = response
    await event.edit(f"✅ **Фильтр добавлен!**\n📌 **Триггер:** `{trigger}`\n💬 **Ответ:** `{response}`")

# Команда для удаления фильтра
@client.on(events.NewMessage(outgoing=True, pattern=r"^\.unfilter (.+)$"))
async def remove_filter(event):
    global filters
    trigger = event.pattern_match.group(1).lower()

    if trigger in filters:
        del filters[trigger]
        await event.edit(f"❌ **Фильтр `{trigger}` удалён!**")
    else:
        await event.edit(f"⚠️ **Фильтр `{trigger}` не найден.**")

# Команда для просмотра списка фильтров
@client.on(events.NewMessage(outgoing=True, pattern=r"^\.filters$"))
async def list_filters(event):
    global filters
    if filters:
        text = "📜 **Активные фильтры:**\n\n"
        for trigger, response in filters.items():
            text += f"🔹 `{trigger}` → `{response}`\n"
        await event.edit(text)
    else:
        await event.edit("⚠️ **Нет активных фильтров.**")

# Автоматический ответ на сообщения, если они совпадают с фильтром
@client.on(events.NewMessage(incoming=True))
async def check_filter(event):
    global filters
    if event.text.lower() in filters:
        await event.reply(filters[event.text.lower()])  # Отвечаем, если есть триггер






@client.on(events.NewMessage(outgoing=True, pattern=r"^\.spam (.+) (\d+) (\d+)$"))
async def spam_command(event):
    args = event.pattern_match.groups()
    message = args[0]  # Текст для спама
    duration = int(args[1])  # Общее время спама
    interval = int(args[2])  # Интервал между сообщениями

    await event.delete()  # Удаляем команду, чтобы не засорять чат

    end_time = asyncio.get_event_loop().time() + duration  # Определяем время завершения

    while asyncio.get_event_loop().time() < end_time:
        await event.respond(message)  # Отправляем сообщение
        await asyncio.sleep(interval)  # Ждём заданный интервал


# Обработчик команды .userinfo
@client.on(events.NewMessage(outgoing=True, pattern=r"^\.userinfo$"))
async def user_info(event):
    user = await event.client.get_me()  # Получаем информацию о текущем пользователе
    user_info_text = (
        f"🧑‍💻 **Информация о пользователе** 🧑‍💻\n\n"
        f"**Имя:** {user.first_name} {user.last_name if user.last_name else ''}\n"
        f"**Юзернейм:** @{user.username if user.username else 'Не установлен'}\n"
        f"**ID:** {user.id}\n"
        f"**Статус:** {user.status}\n"
    )
    
    await event.reply(user_info_text)


prefix = ""  # Переменная для хранения текущего префикса

# Обработчик для команды .prefix
@client.on(events.NewMessage(outgoing=True, pattern=r"^\.prefix (.+)$"))
async def set_prefix(event):
    global prefix
    prefix = event.pattern_match.group(1)  # Получаем префикс из команды
    await event.reply(f"Префикс установлен: {prefix}")

# Обработчик для команды .prefoff
@client.on(events.NewMessage(outgoing=True, pattern=r"^\.prefoff$"))
async def remove_prefix(event):
    global prefix
    prefix = ""  # Убираем префикс
    await event.reply("Префикс выключен.")

# Обработчик для всех исходящих сообщений
@client.on(events.NewMessage(outgoing=True))
async def add_prefix(event):
    if prefix:
        await event.edit(f"{prefix} {event.text}")  # Добавляем префикс к сообщению


# Список слов, которые бот будет использовать при редактировании
angry_words = ["Рукоблуд", "Пидр", "Чмо ебаное", "Полувыпердыш", "Гандон", "Ослина"]

@client.on(events.NewMessage(outgoing=True, pattern=r"^\.angry$"))  # Четкое совпадение с .angry
async def angry_command(event):
    for i in range(10):  # 10 секунд работы
        await asyncio.sleep(0.1)  # Ждем 1 секунду
        await event.edit(angry_words[i % len(angry_words)])  # Меняем текст


@client.on(events.NewMessage(outgoing=True, pattern=r"^\.ping$"))  # Четкое совпадение с .ping
async def ping_command(event):
    start_time = time.time()  # Засекаем время
    msg = await event.edit("Проверяю пинг...")  # Изменяем сообщение
    end_time = time.time()  # Фиксируем время после редактирования
    ping = round((end_time - start_time) * 1000)  # Вычисляем задержку в ms
    await msg.edit(f"🏓 Пинг: {ping} ms")  # Отправляем итоговое значение



@client.on(events.NewMessage(outgoing=True, pattern=r"^\.zakrep$"))  # Четкое совпадение с .zakrep
async def zakrep_command(event):
    chat = await event.get_chat()  # Получаем текущий чат
    msg = event.reply_to_msg_id or event.id  # Если команда отвечает на сообщение — закрепляем его, иначе саму команду

    await event.edit("🔄 Стартуем..")  # Меняем текст команды

    for _ in range(15):  # Цикл на 5 секунд
        await client.pin_message(chat, msg)  # Закрепляем сообщение
        await asyncio.sleep(0.1)  # Ждем 1 секунду
        await client.unpin_message(chat, msg)  # Открепляем сообщение
        await asyncio.sleep(0.1)  # Ждем 1 секунду

    await event.edit("✅  Конец..")  # Финальный статус



print("UserBot запущен...")
client.start()
client.run_until_disconnected()